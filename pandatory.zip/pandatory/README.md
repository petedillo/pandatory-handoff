# Pandatory

## Introduction


Pandatory is a web application designed to help you manage your pantry efficiently. Built with modern web technologies, it offers a seamless and user-friendly experience for organizing your pantry needs.


## Requirements

### Prerequisites

Before running Pandatory, ensure you have the following installed on your machine:

- **Docker**: [Install Docker](https://www.docker.com/)
- **Docker Compose**: [Install Docker Compose](https://docs.docker.com/compose/)

## Running the Application

To get Pandatory up and running, follow these simple steps:

### Clone the Repository

If you haven't already, clone the repository:

```bash
git clone https://github.com/petedillo/pandatory
cd pandatory
```

### Start the Application with Docker Compose

Run the following command to build and start the application:

```bash
docker compose up
```

This will spin up the entire stack, including:

- **Frontend**: React/Vite app running on [http://localhost:5173](http://localhost:5173)
- **Backend**: Express/Node app running on [http://localhost:3000](http://localhost:3000)
- **Database**: Postgres database running on [http://localhost:5432](http://localhost:5432)

### Run Database Migrations

After the containers are up, run the migrations to set up the database schema:

```bash
docker compose exec backend npm run migrate
```

### Seed the Database (Optional)

If you need to populate the database with initial data, run the seeders:

```bash
docker compose exec backend npm run seed
```

### Access the Application

Once everything is running, you can access the application by navigating to:

- **Frontend**: [http://localhost:5173](http://localhost:5173)
- **Backend API**: [http://localhost:3000](http://localhost:3000)

### Stopping the Application

To stop the application, simply run:

```bash
docker-compose down
