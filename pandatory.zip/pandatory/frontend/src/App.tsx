import AppProviders from "./AppProviders";
import AppRoutes from "./AppRoutes";
import Header from "./components/header/Header";
import ModalWrapper from "./components/modal/ModalWrapper";
import {BrowserRouter} from "react-router-dom";

function App() {
    return (
        <AppProviders>
            <BrowserRouter>
                <Header/>
                <AppRoutes/>
                <ModalWrapper/>
            </BrowserRouter>
        </AppProviders>
    );
}

export default App;
