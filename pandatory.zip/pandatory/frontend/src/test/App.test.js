import {render, screen} from '@testing-library/react';
import {expect, test} from 'vitest';
import {BrowserRouter as Router} from 'react-router-dom';
import {App} from '../App.js';

test('renders Dashboard component on initial load', () => {
  render(
    <Router>
      <App />
    </Router>
  );

  expect(screen.getByRole('heading', { name: 'Dashboard' })).toBeInTheDocument();
});

test('renders Shopping component when navigating to /shopping', () => {
  render(
    <Router initialEntries={['/shopping']} initialIndex={0}>
      <App />
    </Router>
  );

  expect(screen.getByRole('heading', { name: 'Shopping' })).toBeInTheDocument();
});
