import {SubHeaderProps} from "../../context/types";
import {useModal} from "../../context/ModalProvider";
import {Box, IconButton, Typography, useTheme} from '@mui/material';
import {Add as AddIcon, List as ListIcon, ViewModule as ViewModuleIcon} from '@mui/icons-material';
import {grey} from "@mui/material/colors";

function SubHeader({toggleView, view, showSearch}: SubHeaderProps) {
    const {openModal} = useModal();
    const theme = useTheme();


    return (
        <Box
            sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                px: 3,
                py: 2,
                width: '100%',
                boxShadow: 2,
            }}
        >
            {/* Left Section: Title and Add Button */}
            <Box sx={{display: 'flex', alignItems: 'center'}}>
                <Typography
                    variant="h6"
                    sx={{
                        mr: 2,
                        fontWeight: 'bold',
                    }}
                >
                    {showSearch ? 'Search Results' : 'My Pantry'}
                </Typography>
                <IconButton
                    color="primary"
                    onClick={() => openModal()}
                    sx={{
                        '&:hover': {
                            backgroundColor: theme.palette.grey[200],
                        },
                    }}
                >
                    <AddIcon/>
                </IconButton>
            </Box>
            {/* Right Section: Tabs for View Toggle */}
            <Box>
                <IconButton
                    onClick={toggleView}
                    sx={{
                        color: grey[400],
                        '&:hover': {
                            color: theme.palette.primary.main,
                            backgroundColor: grey[700],
                        },
                        ...(view === 'card' && {
                            color: theme.palette.primary.main,
                            fontWeight: 'bold',
                        }),
                    }}
                >
                    {view === 'table' ? <ViewModuleIcon/> : <ListIcon/>}
                </IconButton>
            </Box>
        </Box>
    );
}

export default SubHeader;
