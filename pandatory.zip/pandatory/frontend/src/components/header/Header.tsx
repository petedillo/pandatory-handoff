import {useState} from "react";
import {NavLink} from "react-router-dom";
import {
    AppBar,
    Box,
    Drawer,
    IconButton,
    List,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Toolbar,
    Typography,
    useMediaQuery,
    useTheme
} from "@mui/material";
import {FaBars, FaBowlFood, FaClipboardList} from "react-icons/fa6";
import {MdDashboardCustomize} from "react-icons/md";
import {grey} from "@mui/material/colors";
import SearchComponent from "./SearchComponent";

export default function Header() {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

    const handleDrawerToggle = () => {
        setIsDrawerOpen(!isDrawerOpen);
    };

    const handleNavLinkClick = () => {
        setIsDrawerOpen(false);
    };

    return (
        <AppBar position="static" sx={{backgroundColor: grey[900]}}>
            <Toolbar sx={{display: "flex", justifyContent: "space-between"}}>
                {/* Left Side: Logo */}
                <Typography
                    variant="h6"
                    component={NavLink}
                    to="/"
                    onClick={handleNavLinkClick}
                    sx={{
                        textDecoration: "none",
                        color: "white",
                        fontWeight: "bold",
                        transition: "all 0.3s",
                        "&:hover": {transform: "scale(1.1)", color: grey[400]},
                    }}
                >
                    Pandatory
                </Typography>

                {/* Center: Search Component (Hidden on Mobile) */}
                {!isMobile && <SearchComponent/>}

                {/* Right Side: Navigation or Menu Icon */}
                {isMobile ? (
                    <IconButton color="inherit" onClick={handleDrawerToggle}>
                        <FaBars size={24}/>
                    </IconButton>
                ) : (
                    <Box sx={{display: "flex", gap: 2}}>
                        {navLinks.map((link) => (
                            <NavLink key={link.to} to={link.to} onClick={handleNavLinkClick}
                                     style={{textDecoration: "none"}}>
                                <IconButton sx={{color: "white", "&:hover": {color: grey[400]}}}>
                                    <link.icon size={24}/>
                                </IconButton>
                            </NavLink>
                        ))}
                    </Box>
                )}
            </Toolbar>

            {/* Mobile Sidebar (Drawer) */}
            <Drawer anchor="left" open={isDrawerOpen} onClose={handleDrawerToggle}>
                <Box sx={{
                    width: 250,
                    backgroundColor: grey[800],
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    padding: 2
                }}>
                    {/* Mini Search Bar with onSearch prop */}
                    <SearchComponent mini onSearch={handleDrawerToggle}/>

                    {/* Navigation Links */}
                    <List sx={{flexGrow: 1}}>
                        {navLinks.map((link) => (
                            <ListItem key={link.to} disablePadding>
                                <ListItemButton component={NavLink} to={link.to} onClick={handleNavLinkClick}>
                                    <ListItemIcon sx={{color: grey[300]}}>
                                        <link.icon size={20}/>
                                    </ListItemIcon>
                                    <ListItemText primary={link.label} sx={{color: "white"}}/>
                                </ListItemButton>
                            </ListItem>
                        ))}
                    </List>
                </Box>
            </Drawer>
        </AppBar>
    );
}

// Navigation Links Array
const navLinks = [
    {to: "/", label: "Dashboard", icon: MdDashboardCustomize},
    {to: "/shopping", label: "Shopping", icon: FaClipboardList},
    {to: "/inventory", label: "Inventory", icon: FaBowlFood},
];
