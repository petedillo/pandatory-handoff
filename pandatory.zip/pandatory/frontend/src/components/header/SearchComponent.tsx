import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {usePandatoryContext} from "../../context/hooks";
import {FaSearchengin} from 'react-icons/fa6';
import {Box, IconButton, InputAdornment, TextField} from '@mui/material';
import {SearchComponentProps} from "../../context/types";

function SearchComponent({mini, onSearch}: SearchComponentProps) {
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState("");
    const {search} = usePandatoryContext();

    const handleSearch = (event: React.FormEvent) => {
        event.preventDefault();
        search(searchTerm, null).then(r => {
            setSearchTerm('');
            navigate("/search");
        });

        if (onSearch) {
            onSearch();
        }
    };

    return (
        (<Box sx={{display: 'flex', alignItems: 'center', width: '100%', maxWidth: mini ? 200 : 600}}>
            <form onSubmit={handleSearch} style={{width: '100%'}}>
                <TextField
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search..."
                    fullWidth
                    variant="outlined"
                    size={mini ? "small" : "medium"}
                    sx={{
                        backgroundColor: '#333',
                        borderRadius: 1,
                        '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                                borderColor: '#444',
                            },
                            '&:hover fieldset': {
                                borderColor: '#555',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#777',
                            },
                        },
                        '& .MuiInputBase-input': {
                            color: 'white',
                        },
                    }}
                    slotProps={{
                        input: {
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        type="submit"
                                        sx={{
                                            color: 'gray',
                                            '&:hover': {
                                                color: '#fff',
                                                backgroundColor: '#444',
                                            },
                                        }}
                                    >
                                        <FaSearchengin size={20}/>
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }
                    }}
                />
            </form>
        </Box>)
    );
}

export default SearchComponent;
