import {Box, Button} from '@mui/material';
import {DataGrid, GridColDef, GridRowParams, useGridApiRef} from '@mui/x-data-grid';
import {usePandatoryContext, useShoppingContext} from "../../context/hooks";
import {InventoryItem, ShoppingSession} from "../../context/types";
import {ArrowBack} from "@mui/icons-material";
import {useNavigate} from "react-router-dom";

interface ShoppingSessionTableProps {
    session: ShoppingSession;
}

const ShoppingSessionTable: React.FC<ShoppingSessionTableProps> = ({session}) => {
    const {inventory} = usePandatoryContext();
    const apiRef = useGridApiRef();
    const navigate = useNavigate();
    const {addItemsToSession} = useShoppingContext();

    const shoppingItemIds = new Set(
        session.shoppingLists
            ?.map((list) => list.inventoryItem?.id)
            .filter((id): id is number => id !== undefined)
    );

    const columns: GridColDef<InventoryItem>[] = [
        {field: "id", headerName: "ID", width: 90},
        {field: "name", headerName: "Name", width: 200},
        {field: "quantity", headerName: "Quantity", width: 175, editable: true},
        {field: "expirationDate", headerName: "Expiration Date", width: 150},
        {field: 'quantity_to_buy', headerName: 'Qty to Buy', width: 120, editable: true, type: 'number',},
    ];

    const rows = inventory.map((item) => {
        const shoppingListItem = session.shoppingLists?.find((listItem) => listItem.item_id === item.id);
        return {
            id: item.id,
            name: item.name,
            quantity: item.quantity,
            expirationDate: item.expirationDate,
            isRowSelectable: shoppingItemIds.has(item.id),
            isShoppingItem: !!shoppingListItem,
            quantity_to_buy: shoppingListItem ? shoppingListItem.quantity_to_buy : 0,
        };
    }).sort((a, b) => (b.isShoppingItem ? 1 : 0) - (a.isShoppingItem ? 1 : 0));


    const handleAddToShoppingList = () => {
        const items = [...apiRef.current.getSelectedRows().values()].map((row) => row.id);
        addItemsToSession(session.id, items).then(() => {
            const selectedRows = apiRef.current.getSelectedRows();
            selectedRows.forEach((row) => {
                apiRef.current.setRowSelectionModel([]);
                navigate("/shopping")
            });
        })
    };


    return (
        <Box sx={{height: "100%", width: '50%', marginX: "auto"}}>
            <Box sx={{display: 'flex', justifyContent: 'space-between', marginBottom: 2, flexWrap: 'wrap', gap: 2}}>
                <Button startIcon={<ArrowBack/>} onClick={() => navigate("/shopping")} sx={{flex: 1, minWidth: 120}}>
                    Back
                </Button>
                <Button
                    variant="contained"
                    onClick={handleAddToShoppingList}
                    sx={{flex: 1, minWidth: 200}}
                >
                    Add Items to Shopping List
                </Button>
            </Box>
            <DataGrid
                apiRef={apiRef}
                rows={rows}
                columns={columns}
                checkboxSelection
                disableRowSelectionOnClick
                getRowId={(row) => row.id}
                isRowSelectable={(params: GridRowParams) => !shoppingItemIds.has(params.row.id)}
                sx={{
                    width: '100%',
                    maxWidth: '100%',
                    '@media (max-width:600px)': {
                        fontSize: '0.8rem',
                        '& .MuiDataGrid-columnHeader': {
                            fontSize: '0.9rem',
                        },
                    }
                }}
            />
        </Box>
    );
};

export default ShoppingSessionTable;
