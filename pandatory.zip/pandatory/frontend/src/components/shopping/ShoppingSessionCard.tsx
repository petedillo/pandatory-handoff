import {FC, useState} from 'react';
import {Box, Button, Card, CardContent, Collapse, IconButton, Typography, useMediaQuery, useTheme} from '@mui/material';
import ReplayIcon from '@mui/icons-material/Replay';
import {Archive, Cancel, CheckCircle, DoneAll, Edit} from '@mui/icons-material';
import {useShoppingContext} from "../../context/hooks";
import {useModal} from "../../context/ModalProvider";
import {ActionType, InventoryItem, ShoppingList, ShoppingSessionProps} from "../../context/types";
import {useNavigate} from "react-router-dom";

const ShoppingSessionCard: FC<ShoppingSessionProps> = ({session}) => {
    const [open, setOpen] = useState(false);
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const {archiveSession, markItemsAsPurchased} = useShoppingContext();
    const {openConfirmModal} = useModal();
    const navigate = useNavigate();

    const handleToggleCollapse = () => {
        setOpen(!open);
    };

    const handleArchiveSession = () => {
        openConfirmModal(() => {
            archiveSession(session.id);
        }, ActionType.ARCHIVE);
    };

    const handleEditClick = () => {
        navigate(`/shopping-sessions/${session.id}`);
    };

    const handleTogglePurchased = (item: InventoryItem) => {
        openConfirmModal(() => {
            markItemsAsPurchased(session.id, [item.id]);
        }, ActionType.MARK_PURCHASED);
    };

    const handleMarkAllAsPurchased = () => {
        if (session.shoppingLists && session.shoppingLists.length > 0) {
            const allItemIds = session.shoppingLists.filter(item => !item.purchased && item.inventoryItem?.id)
                .map(item => item.inventoryItem!.id);
            openConfirmModal(() => {
                markItemsAsPurchased(session.id, allItemIds);
            }, ActionType.MARK_PURCHASED);
        }
    };

    return (
        <Card
            sx={{
                backgroundColor: 'background.paper',
                boxShadow: 3,
                width: '100%',
                minWidth: 280,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                height: '100%',
                position: 'relative',
            }}
        >
            <IconButton
                onClick={handleArchiveSession}
                disabled={session.archive}
                sx={{
                    position: 'absolute',
                    top: 16,
                    right: 16,
                    zIndex: 10,
                    color: session.archive ? 'grey' : 'text.primary'
                }}
            >
                <Archive/>
            </IconButton>
            <CardContent>
                <Typography
                    variant="h6"
                    sx={{fontSize: {xs: '1.2rem', sm: '1.5rem', md: '1.75rem'}}}
                >
                    {session.name}
                </Typography>

                <Typography
                    variant="body2"
                    color="textSecondary"
                    sx={{fontSize: {xs: '0.8rem', sm: '1rem'}}}
                >
                    Created At: {new Date(session.createdAt).toDateString()}
                </Typography>
                <Typography
                    variant="body2"
                    color="textSecondary"
                    sx={{fontSize: {xs: '0.8rem', sm: '1rem'}}}
                >
                    Updated At: {new Date(session.updatedAt).toDateString()}
                </Typography>
                <Typography
                    variant="h6"
                    sx={{mt: 2, fontSize: {xs: '1rem', sm: '1.25rem', md: '1.5rem'}}}
                >
                    Shopping List
                    {session.shoppingLists && session.shoppingLists.length > 0 && (
                        <Button onClick={handleToggleCollapse} size="small"
                                sx={{ml: 2, fontSize: {xs: '0.75rem', sm: '0.9rem'}}}>
                            {open ? 'Hide' : `Show (${session.shoppingLists.length})`}
                        </Button>
                    )}
                </Typography>
                <Collapse in={open}>
                    <Box sx={{maxHeight: '300px', overflowY: 'auto'}}>
                        {session.shoppingLists?.map((listItem: ShoppingList) => (
                            <Box
                                key={listItem.id}
                                sx={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                    p: 1.5,
                                    borderBottom: 1
                                }}
                            >
                                <Box>
                                    <Typography variant="body2">{listItem.inventoryItem?.name}</Typography>
                                    <Typography variant="caption" color="textSecondary">
                                        Expiration: {listItem.inventoryItem?.expirationDate
                                        ? new Date(listItem.inventoryItem.expirationDate).toDateString()
                                        : "No Expiration Date"}
                                    </Typography>

                                </Box>
                                <IconButton
                                    onClick={() => listItem.inventoryItem && handleTogglePurchased(listItem.inventoryItem)}
                                    disabled={listItem.purchased || !listItem.inventoryItem?.id || session.archive}
                                    sx={{
                                        color: (listItem.purchased || !listItem.inventoryItem?.id || session.archive) ? 'grey' : (listItem.purchased ? 'green' : 'red')
                                    }}
                                >
                                    {listItem.purchased ? (
                                        <CheckCircle/>
                                    ) : (
                                        <Cancel/>
                                    )}
                                </IconButton>
                            </Box>
                        ))}
                    </Box>
                </Collapse>
                <Box sx={{mt: 2, display: 'flex', justifyContent: 'flex-end', gap: 1}}>
                    {!session.archive && (
                        <Button
                            variant="outlined"
                            size="small"
                            startIcon={!isMobile && <Edit/>}
                            onClick={handleEditClick}
                        >
                            {isMobile ? <Edit/> : 'Edit Session'}
                        </Button>
                    )}

                    {!session.archive && (
                        <Button
                            variant="contained"
                            size="small"
                            color="secondary"
                            startIcon={!isMobile && <DoneAll/>}
                            onClick={handleMarkAllAsPurchased}
                        >
                            {isMobile ? <DoneAll/> : 'Mark All as Purchased'}
                        </Button>
                    )}

                    {session.archive && (
                        <Button variant="contained" size="small" color="primary" onClick={handleEditClick}
                                startIcon={!isMobile && <ReplayIcon/>}>
                            {isMobile ? <ReplayIcon/> : 'Re-order'}
                        </Button>
                    )}
                </Box>
            </CardContent>
        </Card>
    );
};

export default ShoppingSessionCard;
