import {formatDate} from "../../context/UTILS";
import {InventoryItem, InventoryProp} from "../../context/types";
import {Box, Card, CardActionArea, CardContent, Typography,} from "@mui/material";
import {useModal} from "../../context/ModalProvider";

export default function InventoryCard({inventory}: InventoryProp) {
    const {openModal} = useModal();
    return (
        <Box
            sx={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
                gap: 2,
                padding: 2,
            }}
        >
            {inventory.map((item: InventoryItem) => (
                <Card
                    key={item.id}
                    sx={{
                        bgcolor: "#1E1E1E",
                        color: "white",
                        boxShadow: 3,
                        borderRadius: 2,
                        transition: "transform 0.2s",
                        "&:hover": {transform: "scale(1.05)", boxShadow: 6},
                    }}
                >
                    <CardActionArea onClick={() => openModal(item)}>
                        <CardContent>
                            <Typography variant="h6" component="div" sx={{fontWeight: "bold"}}>
                                {item.name}
                            </Typography>
                            <Typography variant="body2" color="gray" sx={{mt: 1}}>
                                <strong>Quantity:</strong> {item.quantity}
                            </Typography>
                            <Typography variant="body2" color="gray" sx={{mt: 1}}>
                                <strong>Expiration Date:</strong> {formatDate(item.expirationDate)}
                            </Typography>
                        </CardContent>
                    </CardActionArea>
                </Card>
            ))}
        </Box>
    );
}
