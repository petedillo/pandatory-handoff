import {useState} from "react";
import {usePandatoryContext} from "../../context/hooks";
import {InventoryItem, InventoryProp} from "../../context/types";
import {formatDate} from "../../context/UTILS";

import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";

export default function InventoryTable({inventory}: InventoryProp) {
    const [isEditing, setIsEditing] = useState(false);
    const [editedItem, setEditedItem] = useState<InventoryItem | null>(null);
    const {updateInventory} = usePandatoryContext();

    const handleEditClick = (item: InventoryItem) => {
        setIsEditing(true);
        setEditedItem(item);
    };

    const handleEditSave = (updatedItem: InventoryItem) => {
        setIsEditing(false);
        setEditedItem(null);
        updateInventory(updatedItem);
    };

    const handleEditCancel = () => {
        setIsEditing(false);
        setEditedItem(null);
    };

    return (
        <TableContainer component={Paper} sx={{bgcolor: "#121212", color: "white"}}>
            <Table sx={{minWidth: 650, bgcolor: "#1E1E1E"}} aria-label="inventory table">
                <TableHead>
                    <TableRow sx={{bgcolor: "#222"}}>
                        <TableCell sx={{color: "white", fontWeight: "bold"}}>Name</TableCell>
                        <TableCell sx={{color: "white", fontWeight: "bold"}}>Quantity</TableCell>
                        <TableCell sx={{color: "white", fontWeight: "bold"}}>Expiration Date</TableCell>
                        <TableCell sx={{color: "white", fontWeight: "bold"}}>Actions</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {inventory.map((item: InventoryItem) => (
                        <TableRow
                            key={item.id}
                            sx={{
                                bgcolor: isEditing && editedItem?.id === item.id ? "#333" : "inherit",
                                "&:hover": {bgcolor: "#444"},
                            }}
                        >
                            <TableCell sx={{color: "white"}}>
                                {isEditing && editedItem?.id === item.id ? (
                                    <TextField
                                        variant="outlined"
                                        size="small"
                                        fullWidth
                                        defaultValue={editedItem.name}
                                        onChange={(e) => setEditedItem({...editedItem, name: e.target.value})}
                                        sx={{input: {color: "white"}, bgcolor: "#333", borderRadius: 1}}
                                    />
                                ) : (
                                    item.name
                                )}
                            </TableCell>
                            <TableCell sx={{color: "white"}}>
                                {isEditing && editedItem?.id === item.id ? (
                                    <TextField
                                        type="number"
                                        variant="outlined"
                                        size="small"
                                        fullWidth
                                        defaultValue={editedItem.quantity}
                                        onChange={(e) => setEditedItem({
                                            ...editedItem,
                                            quantity: parseInt(e.target.value)
                                        })}
                                        sx={{input: {color: "white"}, bgcolor: "#333", borderRadius: 1}}
                                    />
                                ) : (
                                    item.quantity
                                )}
                            </TableCell>
                            <TableCell sx={{color: "white"}}>{formatDate(item.expirationDate)}</TableCell>
                            <TableCell>
                                {isEditing && editedItem?.id === item.id ? (
                                    <>
                                        <Button
                                            variant="contained"
                                            sx={{
                                                bgcolor: "#1976D2",
                                                color: "white",
                                                mr: 1,
                                                "&:hover": {bgcolor: "#1565C0"}
                                            }}
                                            onClick={() => handleEditSave(editedItem)}
                                        >
                                            Save
                                        </Button>
                                        <Button
                                            variant="contained"
                                            sx={{bgcolor: "#D32F2F", color: "white", "&:hover": {bgcolor: "#C62828"}}}
                                            onClick={handleEditCancel}
                                        >
                                            Cancel
                                        </Button>
                                    </>
                                ) : (
                                    <Button
                                        variant="contained"
                                        sx={{bgcolor: "#F57C00", color: "white", "&:hover": {bgcolor: "#E65100"}}}
                                        onClick={() => handleEditClick(item)}
                                    >
                                        Edit
                                    </Button>
                                )}
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>

    );
}
