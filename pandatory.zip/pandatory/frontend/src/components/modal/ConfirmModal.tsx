import {Button, Dialog, DialogActions, DialogContent, DialogTitle} from '@mui/material';
import {useModal} from '../../context/ModalProvider';
import {ConfirmModalProps} from "../../context/types"


const ConfirmModal = ({onConfirm, actionType}: ConfirmModalProps) => {
    const {isModalOpen, closeModal} = useModal();

    const getActionDetails = () => {
        switch (actionType) {
            case 'archive':
                return {title: 'Confirm Archive', message: 'Are you sure you want to archive this session?'};
            case 'delete':
                return {
                    title: 'Confirm Deletion',
                    message: 'Are you sure you want to delete this session? This action cannot be undone.'
                };
            case 'markPurchased':
                return {
                    title: 'Confirm Purchase',
                    message: 'Are you sure you want to mark item/s as purchased?'
                };
            default:
                return {title: 'Confirm Action', message: 'Are you sure you want to perform this action?'};
        }
    };

    const {title, message: modalMessage} = getActionDetails();

    return (
        <Dialog open={isModalOpen} onClose={closeModal}>
            <DialogTitle>{title}</DialogTitle>
            <DialogContent>{modalMessage}</DialogContent>
            <DialogActions>
                <Button onClick={closeModal} color="secondary">
                    No
                </Button>
                <Button
                    onClick={() => {
                        onConfirm();
                        closeModal();
                    }}
                    color="primary"
                    autoFocus
                >
                    Yes
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default ConfirmModal;
