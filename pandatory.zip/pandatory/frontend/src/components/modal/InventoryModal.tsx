import {useRef} from "react";
import {Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField} from "@mui/material";
import {InventoryModalProps} from "../../context/types";
import {usePandatoryContext} from "../../context/hooks";
import {useNavigate} from "react-router-dom";

const InventoryModal: React.FC<InventoryModalProps> = ({onClose, item}) => {
    const formRef = useRef<HTMLFormElement>(null);
    const {createInventory, updateInventory} = usePandatoryContext();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!formRef.current) return;

        const formData = new FormData(formRef.current);
        const updatedItem = {
            id: item?.id || 0,
            name: formData.get("name") as string,
            expirationDate: formData.get("expirationDate") as string,
            quantity: parseInt(formData.get("quantity") as string, 10),
        };

        try {
            if (item) {
                updateInventory(updatedItem);
            } else {
                createInventory(updatedItem);
            }
            navigate("/inventory");
            onClose();
        } catch (error) {
            console.error("Error in submitting the form:", error);
        }
    };

    return (
        <Dialog open onClose={onClose} fullWidth maxWidth="sm">
            <DialogTitle>{item ? "Edit Inventory Item" : "Add New Inventory Item"}</DialogTitle>
            <form ref={formRef} onSubmit={handleSubmit}>
                <DialogContent>
                    {/* Item Name */}
                    <TextField
                        fullWidth
                        margin="dense"
                        label="Item Name"
                        name="name"
                        defaultValue={item?.name || ""}
                        required
                    />

                    {/* Expiration Date */}
                    <TextField
                        fullWidth
                        margin="dense"
                        label="Expiration Date"
                        name="expirationDate"
                        type="date"
                        slotProps={{inputLabel: {shrink: true}}}
                        defaultValue={item?.expirationDate || ""}
                        required
                    />

                    {/* Quantity */}
                    <TextField
                        fullWidth
                        margin="dense"
                        label="Quantity"
                        name="quantity"
                        type="number"
                        slotProps={{htmlInput: {min: 1}}}
                        defaultValue={item?.quantity || 1}
                        required
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={onClose} color="secondary">Cancel</Button>
                    <Button type="submit" variant="contained" color="primary">
                        {item ? "Update Item" : "Add Item"}
                    </Button>
                </DialogActions>
            </form>
        </Dialog>
    );
};

export default InventoryModal;
