import {useModal} from "../../context/ModalProvider";
import InventoryModal from "./InventoryModal";
import ConfirmModal from "./ConfirmModal";

export default function ModalWrapper() {
    const {isModalOpen, closeModal, modalState} = useModal();

    return isModalOpen ? (
        <>
            {modalState?.type === "inventory" && (
                <InventoryModal
                    item={modalState.item}
                    onClose={closeModal}
                />
            )}
            {modalState?.type === "confirm" && (
                <ConfirmModal
                    onConfirm={modalState.callback}
                    actionType={modalState.actionType}
                />
            )}
        </>
    ) : null;
}