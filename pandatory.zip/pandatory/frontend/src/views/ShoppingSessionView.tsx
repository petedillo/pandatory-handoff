import {useNavigate, useParams} from 'react-router-dom';
import {useShoppingContext} from "../context/hooks";
import {useEffect, useState} from 'react';
import {ShoppingSession} from '../context/types';
import {Box, Button, CircularProgress, TextField, Typography} from '@mui/material';
import ShoppingSessionTable from "../components/shopping/ShoppingSessionTable";

const ShoppingSessionView = () => {
    const {id} = useParams();
    const {fetchSession, createSession} = useShoppingContext();
    const [session, setSession] = useState<ShoppingSession | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<Error | null>(null);
    const [newSessionName, setNewSessionName] = useState("");
    const navigate = useNavigate()

    useEffect(() => {
        const fetchSessionData = async () => {
            if (id) {
                setLoading(true);
                try {
                    const sessionData = await fetchSession(parseInt(id));
                    setSession(sessionData);
                } catch (err) {
                    setError(err as Error);
                } finally {
                    setLoading(false);
                }
            } else {
                setLoading(false);
            }
        };
        fetchSessionData();
    }, [id]);

    const handleCreateSession = async () => {
        if (!newSessionName.trim()) return;
        try {
            await createSession(newSessionName).then(session => {
                console.table(session)
                navigate(`/shopping-sessions/${session?.id}`)
            });

        } catch (err) {
            setError(err as Error);
        }
    };

    if (loading) return <CircularProgress/>;
    if (error) return <div>Error: {error.message}</div>;

    return (
        <Box sx={{height: '100%', width: '100%', padding: 4, textAlign: 'center'}}>
            {/* Dramatic Header */}
            <Typography
                variant="h1"
                sx={{
                    fontWeight: 'bold',
                    fontSize: '3rem',
                    textTransform: 'uppercase',
                    letterSpacing: 3,
                    textShadow: '4px 4px 6px rgba(0, 0, 0, 0.2), 0 0 25px rgba(0, 0, 0, 0.1)',
                    animation: 'fadeIn 1.5s ease-in-out',
                    mb: 2,
                }}
            >
                Shopping Session
            </Typography>

            {!id ? (
                <Box sx={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2}}>
                    <TextField
                        label="New Shopping Session Name"
                        variant="outlined"
                        value={newSessionName}
                        onChange={(e) => setNewSessionName(e.target.value)}
                    />
                    <Button variant="contained" color="primary" onClick={handleCreateSession}>
                        Create Session
                    </Button>
                </Box>
            ) : session ? (
                <>
                    <Typography
                        variant="h2"
                        sx={{
                            fontWeight: 'lighter',
                            fontSize: '2rem',
                            color: '#1976d2',
                            letterSpacing: 2,
                            textShadow: '2px 2px 4px rgba(0, 0, 0, 0.2)',
                            animation: 'fadeIn 2s ease-in-out',
                            mb: 2,
                        }}
                    >
                        {session.name}
                    </Typography>

                    <Box sx={{display: 'flex', justifyContent: 'center', gap: 4}}>
                        <Typography
                            variant="h5"
                            sx={{
                                fontWeight: 'normal',
                                fontSize: '1.2rem',
                                color: '#757575',
                                textShadow: '1px 1px 3px rgba(0, 0, 0, 0.1)',
                            }}
                        >
                            Created At: {new Date(session.createdAt).toLocaleDateString()}
                        </Typography>

                        <Typography
                            variant="h5"
                            sx={{
                                fontWeight: 'normal',
                                fontSize: '1.2rem',
                                color: '#757575',
                                textShadow: '1px 1px 3px rgba(0, 0, 0, 0.1)',
                            }}
                        >
                            Updated At: {new Date(session.updatedAt).toLocaleDateString()}
                        </Typography>
                    </Box>

                    <ShoppingSessionTable session={session}/>
                </>
            ) : (
                <div>Session not found.</div>
            )}
        </Box>
    );
};

export default ShoppingSessionView;
