import SubHeader from '../components/header/SubHeader';
import InventoryTable from '../components/inventory/InventoryTable';
import InventoryCard from '../components/inventory/InventoryCard';
import {usePandatoryContext} from '../context/hooks';
import {useLocation} from 'react-router-dom';

function List() {
    const {inventory, isLoading, error, view, toggleView, searchResults,} = usePandatoryContext();
    const {pathname} = useLocation();
    const showSearch = pathname ? pathname.includes("/search") : pathname ? pathname.includes("/inventory") : false

    if (isLoading) return <p>Loading...</p>;
    if (error) return <p>Error: {error.message}</p>;

    const renderInventory = () => {
        const data = showSearch ? searchResults : inventory;
        return view === 'card' ? (
            <InventoryTable inventory={data}/>
        ) : (
            <InventoryCard inventory={data}/>
        );
    };

    return (<div className="flex flex-col">
        <SubHeader toggleView={toggleView} showSearch={showSearch} view={view}/>
        {renderInventory()}
    </div>);
}

export default List;