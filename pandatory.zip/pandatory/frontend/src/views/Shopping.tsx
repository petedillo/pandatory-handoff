import {
    BottomNavigation,
    BottomNavigationAction,
    Box,
    Button,
    Card,
    CardContent,
    Container,
    Fab,
    Grid2,
    Tab,
    Tabs,
    Typography,
    useMediaQuery
} from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import ArchiveIcon from '@mui/icons-material/Archive';
import AddIcon from '@mui/icons-material/Add';
import ShoppingSessionCard from '../components/shopping/ShoppingSessionCard';
import {useTheme} from '@mui/material/styles';
import {useShoppingContext} from "../context/hooks";
import {useNavigate} from "react-router-dom";

const Shopping = () => {
    const {shoppingSessions, selectedTab, setSelectedTab} = useShoppingContext();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const navigate = useNavigate()
    const handleTabChange = (event: React.SyntheticEvent | Event, newValue: 0 | 1) => {
        setSelectedTab(newValue);
    };

    const createShoppingSession = () => {
        navigate("/shopping-sessions")
    };


    return (
        <Container maxWidth="md" sx={{p: 2, backgroundColor: 'background.default'}}>
            <Box sx={{mb: 2}}>
                {isMobile ? (
                    <>
                        <BottomNavigation
                            value={selectedTab}
                            onChange={handleTabChange}
                            showLabels
                            sx={{
                                position: 'fixed',
                                bottom: 0,
                                left: 0,
                                right: 0,
                                zIndex: 1000,
                                backgroundColor: 'background.paper'
                            }}
                        >
                            <BottomNavigationAction label="Shopping" icon={<ShoppingCartIcon/>} value={0}/>
                            <BottomNavigationAction label="Archived" icon={<ArchiveIcon/>} value={1}/>
                        </BottomNavigation>
                        <Fab
                            color="primary"
                            aria-label="add"
                            sx={{position: 'fixed', bottom: 72, right: 16, zIndex: 1100}}
                            onClick={createShoppingSession}
                        >
                            <AddIcon/>
                        </Fab>
                    </>
                ) : (
                    <Box sx={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2}}>
                        <Tabs
                            value={selectedTab}
                            onChange={handleTabChange}
                            indicatorColor="primary"
                            textColor="primary"
                            sx={{flexGrow: 1}}
                        >
                            <Tab label="Shopping Sessions" value={0}/>
                            <Tab label="Archived Sessions" value={1}/>
                        </Tabs>
                        <Button variant="contained" color="primary" onClick={createShoppingSession}
                                startIcon={<AddIcon/>}>
                            Create Session
                        </Button>
                    </Box>
                )}

                <Box sx={{mt: 2}}>
                    {selectedTab === 0 ? (
                        <Typography variant="h6">View your active shopping sessions.</Typography>
                    ) : (
                        <Typography variant="h6">View your archived shopping sessions.</Typography>
                    )}
                </Box>
            </Box>

            <Grid2 container spacing={3} justifyContent="center" alignItems="stretch">
                {shoppingSessions.length > 0 ? (
                    shoppingSessions.map((session) => (
                        // @ts-ignore
                        <Grid2 item xs={12} sm={6} md={4} key={session.id} component="section">
                            <ShoppingSessionCard session={session}/>
                        </Grid2>
                    ))
                ) : (
                    // @ts-ignore
                    <Grid2 item xs={12} display="flex" justifyContent="center" component="section">
                        <Card sx={{width: '100%', maxWidth: 400}}>
                            <CardContent>
                                <Typography variant="body1" color="textSecondary" textAlign="center">
                                    No shopping sessions available. Please add a new session.
                                </Typography>
                            </CardContent>
                        </Card>
                    </Grid2>
                )}
            </Grid2>
        </Container>
    );
};

export default Shopping;
