import {useEffect, useState} from "react";
import {Box, Card, CardContent, Grid2, Typography} from "@mui/material";
import {PieChart} from "@mui/x-charts/PieChart";
import {BarChart} from "@mui/x-charts/BarChart";
import {fetchData} from "../context/UTILS";

function Dashboard() {
    const API_ENDPOINT: URL = new URL(
        // @ts-ignore
        `${import.meta.env.VITE_API_ENDPOINT}/dashboard`
    );

    const [stats, setStats] = useState({
        totalItems: 0,
        expiringSoon: 0,
        needsAttention: 0,
        totalSessions: 0,
    });


    useEffect(() => {
        fetchData(API_ENDPOINT)
            .then((data) => setStats(data))
            .catch((error) => console.error("Error fetching dashboard data:", error));
    }, []);

    // Pantry Pie Data
    const pantryData = [
        {id: 0, value: stats.totalItems, label: 'Total Items'},
        {id: 1, value: stats.expiringSoon, label: 'Expiring Soon'},
        {id: 2, value: stats.needsAttention, label: 'Needs Attention'},
    ];

    // Shopping Sessions Bar Data
    const sessionsData = [
        {month: "Sessions", seoul: stats.totalSessions},
    ];


    return (
        <Box className="min-h-screen bg-gray-900 text-gray-200 p-6">
            <Grid2 container spacing={4}>
                {/* Stats Cards */}
                {/*@ts-ignore*/}
                <Grid2 xs={12} md={6} component="section">
                    <Card>
                        <CardContent>
                            <Typography variant="h6" gutterBottom>
                                Pantry Overview
                            </Typography>
                            <Typography>Total Items: {stats.totalItems}</Typography>
                            <Typography>Expiring Soon: {stats.expiringSoon}</Typography>
                            <Typography>Needs Attention: {stats.needsAttention}</Typography>
                        </CardContent>
                    </Card>
                </Grid2>
                {/*@ts-ignore*/}
                <Grid2 xs={12} md={6} component="section">
                    <Card>
                        <CardContent>
                            <Typography variant="h6" gutterBottom>
                                Shopping Overview
                            </Typography>
                            <Typography>Total Shopping Sessions: {stats.totalSessions}</Typography>
                        </CardContent>
                    </Card>
                </Grid2>

                {/* Charts */}
                {/*@ts-ignore*/}
                <Grid2 xs={12} md={6} component="section">
                    <Card>
                        <CardContent>
                            <Typography variant="h6" gutterBottom>
                                Pantry Status
                            </Typography>
                            <PieChart
                                series={[
                                    {
                                        data: pantryData,
                                    },
                                ]}
                                width={400}
                                height={200}
                            />
                        </CardContent>
                    </Card>
                </Grid2>
                {/*@ts-ignore*/}
                <Grid2 xs={12} md={6} component="section">
                    <Card>
                        <CardContent>
                            <Typography variant="h6" gutterBottom>
                                Shopping Sessions
                            </Typography>
                            <BarChart
                                dataset={sessionsData}
                                yAxis={[{scaleType: 'band', dataKey: 'month'}]}
                                series={[
                                    {
                                        dataKey: 'seoul',
                                        label: 'Shopping Sessions',
                                    },
                                ]}
                                layout="horizontal"
                                width={500}
                                height={400}
                            />
                        </CardContent>
                    </Card>
                </Grid2>
            </Grid2>
        </Box>
    );
}

export default Dashboard;
