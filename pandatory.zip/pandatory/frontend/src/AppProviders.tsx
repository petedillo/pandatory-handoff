import {createTheme, ThemeProvider} from "@mui/material/styles";
import {CssBaseline} from "@mui/material";
import {PandatoryProvider} from "./context/PandatoryProvider";
import {ShoppingProvider} from "./context/ShoppingProvider";
import {ModalProvider} from "./context/ModalProvider";
import {AlertProvider} from "./context/AlertContext";

const theme = createTheme({
    palette: {
        mode: "dark",
    },
});

const AppProviders = ({children}: { children: React.ReactNode }) => {
    return (
        <ThemeProvider theme={theme}>
            <CssBaseline/>
            <AlertProvider>
                <PandatoryProvider>
                    <ShoppingProvider>
                        <ModalProvider>{children}</ModalProvider>
                    </ShoppingProvider>
                </PandatoryProvider>
            </AlertProvider>
        </ThemeProvider>
    );
};

export default AppProviders;
