import {lazy, Suspense} from "react";
import {Route, Routes} from "react-router-dom";
import {CircularProgress} from '@mui/material'

// Lazy-loaded views for better performance
const Dashboard = lazy(() => import("./views/Dashboard"));
const List = lazy(() => import("./views/List"));
const Shopping = lazy(() => import("./views/Shopping"));
const ShoppingSession = lazy(() => import("./views/ShoppingSessionView"));

const AppRoutes = () => {
    return (
        <Suspense fallback={<CircularProgress/>}>
            <Routes>
                <Route path="/" element={<Dashboard/>}/>
                <Route path="/shopping" element={<Shopping/>}/>
                <Route path="/shopping-sessions/:id?" element={<ShoppingSession/>}/>
                <Route path="/inventory" element={<List/>}/>
                <Route path="/search" element={<List/>}/>
            </Routes>
        </Suspense>
    );
};

export default AppRoutes;
