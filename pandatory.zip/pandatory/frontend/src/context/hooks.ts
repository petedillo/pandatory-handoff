import {useContext} from 'react';
import {PandatoryContext, ShoppingContext} from './Context';

export const usePandatoryContext = () => {
    const context = useContext(PandatoryContext);
    if (!context) {
        throw new Error('useInventoryContext must be used within an InventoryProvider');
    }
    return context;
};
export const useShoppingContext = () => {
    const context = useContext(ShoppingContext);
    if (!context) {
        throw new Error('useInventoryContext must be used within an ShoppingProvider');
    }
    return context;
};