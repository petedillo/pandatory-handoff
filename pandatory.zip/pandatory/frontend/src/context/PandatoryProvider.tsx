import {useEffect, useState} from "react";
import {PandatoryContext} from "./Context";
import {InventoryItem, PandatoryProviderProps, SeverityType} from "./types";
import {useAlert} from './AlertContext';

export const PandatoryProvider: React.FC<PandatoryProviderProps> = ({children}) => {
    const API_ENDPOINT: URL = new URL(
        // @ts-ignore
        `${import.meta.env.VITE_API_ENDPOINT || "http://localhost:3000/api/v1"}/inventory`
    );
    const [inventory, setInventory] = useState<InventoryItem[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<Error | null>(null);
    const [view, setView] = useState<string>("table");
    const [searchResults, setSearchResults] = useState<InventoryItem[]>([]);
    const {showAlert} = useAlert();

    // Fetch all inventory items
    const fetchData = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(API_ENDPOINT);
            const data = await response.json();
            setInventory(data);
        } catch (err) {
            setError(err as Error);
        } finally {
            setIsLoading(false);
        }
    };

    // Search for inventory items
    const search = async (name?: string, expirationDate?: string | null) => {
        setIsLoading(true);
        setError(null);
        try {
            let url = new URL(API_ENDPOINT + "/search");
            if (name) {
                url.searchParams.append('name', name);
            }
            if (expirationDate) {
                url.searchParams.append('expirationDate', expirationDate);
            }

            const response = await fetch(url);
            const data = await response.json().then(data => data.results);
            setSearchResults(data);
        } catch (error) {
            setError(error as Error);
        } finally {
            setIsLoading(false);
        }
    };

    // Toggle the view between table and card
    const toggleView = () => {
        setView((prevView) => (prevView === "table" ? "card" : "table"));
    };

    // Create a new inventory item
    const createInventory = async (newItem: InventoryItem) => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(newItem),
            });
            if (!response.ok) {
                throw new Error("Failed to create inventory item");
            }
            await fetchData();

            // Success alert
            showAlert("Inventory item created successfully!", SeverityType.SUCCESS);
        } catch (error) {
            setError(error as Error);

            // Error alert
            showAlert("Failed to create inventory item. Please try again.", SeverityType.ERROR);
        } finally {
            setIsLoading(false);
        }
    };

// Update an existing inventory item
    const updateInventory = async (updatedItem: InventoryItem) => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`${API_ENDPOINT}/${updatedItem.id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(updatedItem),
            });
            if (!response.ok) {
                throw new Error("Failed to update inventory item");
            }
            await fetchData();

            // Success alert
            showAlert("Inventory item updated successfully!", SeverityType.SUCCESS);
        } catch (error) {
            setError(error as Error);

            // Error alert
            showAlert("Failed to update inventory item. Please try again.", SeverityType.ERROR);
        } finally {
            setIsLoading(false);
        }
    };

    // Fetch inventory on initial load
    useEffect(() => {
        fetchData();
    }, []);

    return (
        <PandatoryContext.Provider
            value={{
                inventory,
                isLoading,
                error,
                view,
                searchResults,
                fetchData,
                toggleView,
                search,
                createInventory,
                updateInventory,
            }}
        >
            {children}
        </PandatoryContext.Provider>
    );
};
