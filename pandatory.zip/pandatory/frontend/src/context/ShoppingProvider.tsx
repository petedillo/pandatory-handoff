import {ReactNode, useEffect, useState} from 'react';
import {ShoppingContext} from "./Context";
import {fetchData} from "./UTILS";
import {useAlert} from "./AlertContext";
import {SeverityType, ShoppingList, ShoppingSession} from "./types";

export const ShoppingProvider = ({children}: { children: ReactNode }) => {
    const API_ENDPOINT: URL = new URL(
        // @ts-ignore
        `${import.meta.env.VITE_API_ENDPOINT}/shopping`
    );
    const [shoppingList, setShoppingList] = useState<ShoppingList[]>([]);
    const [shoppingSessions, setShoppingSessions] = useState<ShoppingSession[]>([]);
    const [loading, setIsLoading] = useState(false);
    const [error, setError] = useState<Error | null>(null);
    const [selectedTab, setSelectedTab] = useState(0);
    const {showAlert} = useAlert();

    const getShoppingSession = async (archived = false) => {
        const SESSIONS_ENDPOINT = new URL(`${API_ENDPOINT}/sessions?archived=${archived}`);
        setError(null);
        setIsLoading(true);
        try {
            const data = await fetchData(SESSIONS_ENDPOINT);
            setShoppingSessions(data);
        } catch (e) {
            setError(e as Error);
            showAlert("Failed to fetch shopping sessions. Please try again.", SeverityType.ERROR);
        } finally {
            setIsLoading(false);
        }
    };

    const archiveSession = async (sessionId: number) => {
        const ARCHIVE_ENDPOINT = new URL(`${API_ENDPOINT}/sessions/archive/${sessionId}`);
        setError(null);
        setIsLoading(true);
        try {
            const data = await fetchData(ARCHIVE_ENDPOINT, 'PUT'); // Await the fetch
            showAlert("Shopping session archived successfully!", SeverityType.SUCCESS);
            await getShoppingSession(); // Await the refresh
        } catch (e) {
            setError(e as Error);
            showAlert("Failed to archive shopping session. Please try again.", SeverityType.ERROR); // Show alert
        } finally {
            setIsLoading(false);
        }
    };

    const fetchSession = async (sessionId: number) => {
        const SESSIONS_ENDPOINT = new URL(`${API_ENDPOINT}/sessions/${sessionId}`);
        setError(null);
        setIsLoading(true);
        try {
            const data = await fetchData(SESSIONS_ENDPOINT);
            return data;
        } catch (e) {
            setError(e as Error);
            showAlert("Failed to fetch shopping session. Please try again.", SeverityType.ERROR);
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    const addItemsToSession = async (sessionId: number, itemIds: number[]) => {
        const ADD_ITEMS_ENDPOINT = new URL(`${API_ENDPOINT}/sessions/${sessionId}/add-items`);
        setError(null);
        setIsLoading(true);
        try {
            const response = await fetchData(ADD_ITEMS_ENDPOINT, 'POST', {itemIds});
            showAlert("Items added to shopping session successfully!", SeverityType.SUCCESS);
            await getShoppingSession(selectedTab === 1);
        } catch (e) {
            setError(e as Error);
            showAlert("Failed to add items. Please try again.", SeverityType.ERROR);
        } finally {
            setIsLoading(false);
        }
    };

    const markItemsAsPurchased = async (sessionId: number, itemIds: number[]) => {
        const MARK_PURCHASED_ENDPOINT = new URL(`${API_ENDPOINT}/sessions/${sessionId}/mark-purchased`);
        setError(null);
        setIsLoading(true);
        try {
            const response = await fetchData(MARK_PURCHASED_ENDPOINT, 'POST', {itemIds});
            showAlert("Items marked as purchased successfully!", SeverityType.SUCCESS);
            await getShoppingSession(selectedTab === 1);
        } catch (e) {
            setError(e as Error);
            showAlert("Failed to mark items as purchased. Please try again.", SeverityType.ERROR);
        } finally {
            setIsLoading(false);
        }
    };

    const createSession = async (sessionName: string) => {
        const CREATE_SESSION_ENDPOINT = new URL(`${API_ENDPOINT}/sessions`);
        setError(null);
        setIsLoading(true);
        try {
            const response: ShoppingSession = await fetchData(CREATE_SESSION_ENDPOINT, 'POST', {
                name: sessionName,
                archive: false
            });
            showAlert("Shopping session created successfully!", SeverityType.SUCCESS);
            await getShoppingSession()
            return response;
        } catch (e) {
            setError(e as Error);
            showAlert("Failed to create shopping session. Please try again.", SeverityType.ERROR);
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    const updateQuantity = async (sessionId: number, itemId: number | string, quantity: number) => {
        const UPDATE_QUANTITY_ENDPOINT = new URL(`${API_ENDPOINT}/shopping-sessions/${sessionId}/items/${itemId}/quantity`);
        setError(null);
        setIsLoading(true);

        try {
            const response = await fetchData(UPDATE_QUANTITY_ENDPOINT, 'PUT', {quantity})
            showAlert("Quantity updated successfully!", SeverityType.SUCCESS);
            await getShoppingSession(selectedTab === 1);
            return response.json();

        } catch (e) {
            setError(e as Error);
            showAlert(`Failed to update quantity`, SeverityType.ERROR);
            return null;
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        getShoppingSession(selectedTab === 1);
    }, [selectedTab]);

    return (
        <ShoppingContext.Provider
            value={{
                shoppingList,
                shoppingSessions,
                selectedTab,
                setSelectedTab,
                archiveSession,
                setShoppingList,
                fetchSession,
                loading,
                addItemsToSession,
                markItemsAsPurchased,
                createSession,
                updateQuantity
            }}
        >
            {children}
        </ShoppingContext.Provider>
    );
};
