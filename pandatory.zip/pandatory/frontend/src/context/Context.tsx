// Context.tsx
import {createContext, useContext} from "react";
import {PandatoryContextProps, ShoppingContextProps} from "./types"


export const PandatoryContext = createContext<PandatoryContextProps | undefined>(undefined);

export const usePandatoryContext = () => {
    const context = useContext(PandatoryContext);
    if (!context) {
        throw new Error("usePandatoryContext must be used within a PandatoryProvider");
    }
    return context;
};

export const ShoppingContext = createContext<ShoppingContextProps | undefined>(undefined);

export const useShoppingContext = () => {
    const context = useContext(ShoppingContext);
    if (!context) {
        throw new Error("usePandatoryContext must be used within a PandatoryProvider");
    }
    return context;
};