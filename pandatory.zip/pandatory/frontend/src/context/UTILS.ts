interface FetchOptions extends RequestInit {
    body?: string | null;
}

export const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
};

export const fetchData = async (endpoint: URL, method = 'GET', body: any = null) => {
    const options: FetchOptions = {
        method,
        headers: {
            'Content-Type': 'application/json',
        },
    };

    if (body) {
        options.body = JSON.stringify(body);
    }

    try {
        const response = await fetch(endpoint, options);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        return data;
    } catch (err) {
        console.error("Error in fetchData:", err);
        throw err;
    }
};
