import {ReactNode} from "react";

export interface PandatoryProviderProps {
    children: ReactNode;
}

export interface ShoppingSession {
    id: number;
    name: string;
    archive: boolean;
    createdAt: string;
    updatedAt: string;
    shoppingLists?: ShoppingList[];
}

export interface ShoppingList {
    id: number;
    item_id: number;
    quantity_to_buy: number;
    purchased: boolean;
    session_id: number;
    inventoryItem?: InventoryItem;
    shoppingSession?: ShoppingSession;
}

export type InventoryItem = {
    id: number;
    name: string;
    expirationDate: string;
    createdAt?: string;
    updatedAt?: string;
    quantity: number;
}
export type InventoryProp = {
    inventory: InventoryItem[];
}

export interface SubHeaderProps {
    toggleView: () => void;
    view: string;
    showSearch: boolean;
}

export interface InventoryModalProps {
    onClose: () => void;
    item?: InventoryItem | null
}

export interface PandatoryContextProps {
    inventory: InventoryItem[];
    isLoading: boolean;
    error: Error | null;
    view: string;
    searchResults: InventoryItem[];
    fetchData: () => Promise<void>;
    toggleView: () => void;
    search: (name: string, expirationDate: string | null) => Promise<void>;
    createInventory: (newItem: InventoryItem) => void;
    updateInventory: (updatedItem: InventoryItem) => void;
}


export interface ShoppingContextProps {
    shoppingList: ShoppingList[] | null;
    shoppingSessions: ShoppingSession[];
    selectedTab: number;
    setSelectedTab: (tabIndex: number) => void;
    archiveSession: (sessionId: number) => void;
    setShoppingList: (shoppingList: ShoppingList[]) => void;
    fetchSession: (sessionId: number) => Promise<ShoppingSession | null>;
    loading: boolean;
    addItemsToSession: (sessionId: number, itemIds: number[]) => Promise<void>;
    markItemsAsPurchased: (sessionId: number, itemIds: number[]) => Promise<void>;
    createSession: (sessionName: string) => Promise<ShoppingSession | null>;
    updateQuantity: (sessionId: number, itemId: number | string, quantity: number) => Promise<any>;
}


export interface SearchComponentProps {
    mini?: boolean;
    onSearch?: () => void;
}


export type AlertContextType = {
    alert: { message: string; severity: SeverityType };
    showAlert: (message: string, severity: SeverityType) => void;
    clearAlert: () => void;
};

export enum SeverityType {
    SUCCESS = "success",
    ERROR = "error",
    INFO = "info",
    WARNING = "warning",
}

export enum ActionType {
    ARCHIVE = "archive",
    DELETE = "delete",
    MARK_PURCHASED = "markPurchased",
    GENERIC = "generic",
}

export interface ModalContextProps {
    isModalOpen: boolean;
    openModal: (item?: InventoryItem) => void;
    closeModal: () => void;
    openConfirmModal: (callBack: () => void, actionType: ActionType, message?: string) => void;
    modalState?: ModalState;
}

export type ModalState =
    | {
    type: "inventory";
    item: InventoryItem | null;
}
    | {
    type: "confirm";
    callback: VoidFunction;
    actionType: ActionType;
    message?: string;
}
export interface ConfirmModalProps {
    onConfirm: () => void;
    actionType: ActionType;
}

export interface ShoppingSessionProps {
    session: ShoppingSession;
}