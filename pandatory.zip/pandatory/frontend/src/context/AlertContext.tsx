// @ts-ignore
import React, {createContext, useContext, useState} from 'react';
import {Alert, Snackbar} from '@mui/material';
import {Check as CheckIcon, Error as ErrorIcon} from '@mui/icons-material';
import {AlertContextType, SeverityType} from './types';

const AlertContext = createContext<AlertContextType | undefined>(undefined);

export const useAlert = () => {
    const context = useContext(AlertContext);
    if (!context) {
        throw new Error('useAlert must be used within an AlertProvider');
    }
    return context;
};

export const AlertProvider: React.FC = ({children}: { children: React.ReactNode }) => {
    const [alert, setAlert] = useState({message: '', severity: SeverityType.SUCCESS});
    const [open, setOpen] = useState(false);

    const showAlert = (message: string, severity: SeverityType) => {
        setAlert({message, severity});
        setOpen(true);
    };

    const clearAlert = () => {
        setOpen(false);
    };

    return (
        (<AlertContext.Provider value={{alert, showAlert, clearAlert}}>
            {/* Snackbar positioned at the bottom */}
            <Snackbar
                open={open}
                autoHideDuration={3000}
                onClose={clearAlert}
                anchorOrigin={{vertical: 'bottom', horizontal: 'center'}}
            >
                <Alert
                    onClose={clearAlert}
                    icon={alert.severity === SeverityType.SUCCESS ? <CheckIcon fontSize="inherit"/> :
                        <ErrorIcon fontSize="inherit"/>}
                    // @ts-ignore
                    severity={alert.severity}
                    sx={{width: '100%'}}
                >
                    {alert.message}
                </Alert>
            </Snackbar>
            {children}
        </AlertContext.Provider>)
    );
};
