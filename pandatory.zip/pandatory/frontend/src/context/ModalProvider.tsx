import {createContext, useContext, useMemo, useState} from "react";
import {ActionType, InventoryItem, ModalContextProps, ModalState} from "./types";

const ModalContext = createContext<ModalContextProps | undefined>(undefined);

export function ModalProvider({children}: { children: React.ReactNode }) {
    const [modalState, setModalState] = useState<ModalState | undefined>();

    const isModalOpen = useMemo(() => !!modalState, [modalState]);

    const openModal = (item?: InventoryItem) => {
        setModalState({type: "inventory", item} as ModalState);
    };

    const closeModal = () => {
        setModalState(undefined);
    };

    const openConfirmModal = (callback: () => void, actionType: ActionType) => {
        setModalState({type: "confirm", callback, actionType} as ModalState);
    };


    return (
        <ModalContext.Provider
            value={{isModalOpen, openModal, closeModal, openConfirmModal, modalState}}>
            {children}
        </ModalContext.Provider>
    );
}

export function useModal() {
    const context = useContext(ModalContext);
    if (!context) {
        throw new Error("useModal must be used within a ModalProvider");
    }
    return context;
}
