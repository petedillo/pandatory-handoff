'use strict';
const {
    Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class ShoppingList extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            // Link ShoppingList to Inventory
            ShoppingList.belongsTo(models.Inventory, {
                foreignKey: 'item_id',
                as: 'inventoryItem',
            });

            // Link ShoppingList to ShoppingSession
            ShoppingList.belongsTo(models.ShoppingSession, {
                foreignKey: 'session_id',
                as: 'shoppingSession',
            });
        }
    }

    ShoppingList.init({
        item_id: DataTypes.INTEGER,
        quantity_to_buy: DataTypes.INTEGER,
        purchased: DataTypes.BOOLEAN,
        session_id: DataTypes.INTEGER
    }, {
        sequelize,
        modelName: 'ShoppingList',
    });
    return ShoppingList;
};