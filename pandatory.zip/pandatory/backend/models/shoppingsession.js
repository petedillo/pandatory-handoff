'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class ShoppingSession extends Model {
        static associate(models) {
            // A ShoppingSession has many ShoppingList entries
            ShoppingSession.hasMany(models.ShoppingList, {
                foreignKey: 'session_id',
                as: 'shoppingLists',
            });
        }
    }

    ShoppingSession.init({
        name: DataTypes.STRING,
        archive: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        createdAt: DataTypes.DATE,
        updatedAt: DataTypes.DATE,
    }, {
        sequelize,
        modelName: 'ShoppingSession',
    });
    return ShoppingSession;
};
