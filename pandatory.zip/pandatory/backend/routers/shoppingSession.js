const express = require('express');
const router = express.Router();
const shoppingSessionController = require('../controllers/shoppingsession');

// Get all sessions
router.get('/sessions', shoppingSessionController.getAll);

// Create a new session
router.post('/sessions', shoppingSessionController.create);

// Get a session by ID
router.get('/sessions/:id', shoppingSessionController.getById);

// Delete a session
router.delete('/sessions/:id', shoppingSessionController.remove);

// Archive a session (PUT)
router.put('/sessions/archive/:id', shoppingSessionController.archive);

// Add items to a shopping session
router.post('/sessions/:sessionId/add-items', shoppingSessionController.addItems);

// Mark items as purchased
router.post('/sessions/:sessionId/mark-purchased', shoppingSessionController.markPurchased);

// Update items Quantity to buy
router.put('/shopping-sessions/:sessionId/items/:itemId/quantity', shoppingSessionController.updateQuantityToBuy)

module.exports = router;
