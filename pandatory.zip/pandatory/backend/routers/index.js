const express = require('express');
const router = express.Router();

const inventoryRoutes = require('./inventory');
const shoppingSessionRoutes = require('./shoppingSession');
const shoppingListRoutes = require('./shoppingList');
const dashboardRoutes = require('./dashboard');

router.use('/inventory', inventoryRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/shopping', shoppingSessionRoutes, shoppingListRoutes);

module.exports = router;
