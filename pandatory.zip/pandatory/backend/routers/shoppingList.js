const express = require('express');
const router = express.Router();
const shoppingListController = require('../controllers/shoppinglist');

router.get('/list', shoppingListController.getAll);
router.post('/list', shoppingListController.create);
router.get('/list/:id', shoppingListController.getById);
router.delete('/list/:id', shoppingListController.remove);

module.exports = router;
