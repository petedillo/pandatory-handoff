const express = require(`express`)
const inventoryController = require(`../controllers/inventory.js`)
const router = new express.Router()

router.get("/", inventoryController.getAll)
router.post("/", inventoryController.create)
router.get("/search", inventoryController.search)
router.get("/:id", inventoryController.getById)
router.put("/:id", inventoryController.update)
router.delete("/:id", inventoryController.remove)



module.exports = router