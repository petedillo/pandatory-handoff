'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        /**
         * Add seed commands here.
         *
         * Example:
         * await queryInterface.bulkInsert('People', [{
         *   name: 'John Doe',
         *   isBetaMember: false
         * }], {});
         */
        await queryInterface.bulkInsert('Inventories',
            [
                {
                    name: 'Pinto Beans',
                    expirationDate: '2025-06-15',
                    createdAt: '2024-01-01',
                    updatedAt: '2024-01-05',
                    quantity: 150
                },
                {
                    name: 'Jasmine Rice',
                    expirationDate: '2026-01-10',
                    createdAt: '2024-01-02',
                    updatedAt: '2024-01-06',
                    quantity: 200
                },
                {
                    name: 'Black Beans',
                    expirationDate: '2025-05-20',
                    createdAt: '2024-01-03',
                    updatedAt: '2024-01-07',
                    quantity: 120
                },
                {
                    name: 'Brown Rice',
                    expirationDate: '2026-03-01',
                    createdAt: '2024-01-04',
                    updatedAt: '2024-01-08',
                    quantity: 180
                },
                {
                    name: 'Quinoa',
                    expirationDate: '2025-12-25',
                    createdAt: '2024-01-05',
                    updatedAt: '2024-01-09',
                    quantity: 90
                },
                {
                    name: 'Lentils',
                    expirationDate: '2025-09-15',
                    createdAt: '2024-01-06',
                    updatedAt: '2024-01-10',
                    quantity: 140
                },
                {
                    name: 'Chickpeas',
                    expirationDate: '2025-11-30',
                    createdAt: '2024-01-07',
                    updatedAt: '2024-01-11',
                    quantity: 160
                },
                {
                    name: 'Basmati Rice',
                    expirationDate: '2026-02-14',
                    createdAt: '2024-01-08',
                    updatedAt: '2024-01-12',
                    quantity: 220
                },
                {
                    name: 'Rolled Oats',
                    expirationDate: '2025-07-19',
                    createdAt: '2024-01-09',
                    updatedAt: '2024-01-13',
                    quantity: 130
                },
                {
                    name: 'Almonds',
                    expirationDate: '2025-10-10',
                    createdAt: '2024-01-10',
                    updatedAt: '2024-01-14',
                    quantity: 75
                },
                {
                    name: 'Walnuts',
                    expirationDate: '2025-08-22',
                    createdAt: '2024-01-11',
                    updatedAt: '2024-01-15',
                    quantity: 85
                },
                {
                    name: 'Dried Cranberries',
                    expirationDate: '2025-12-05',
                    createdAt: '2024-01-12',
                    updatedAt: '2024-01-16',
                    quantity: 95
                },
                {
                    name: 'Cashews',
                    expirationDate: '2025-11-18',
                    createdAt: '2024-01-13',
                    updatedAt: '2024-01-17',
                    quantity: 110
                },
                {
                    name: 'Sunflower Seeds',
                    expirationDate: '2025-09-29',
                    createdAt: '2024-01-14',
                    updatedAt: '2024-01-18',
                    quantity: 105
                },
                {
                    name: 'Pumpkin Seeds',
                    expirationDate: '2025-10-30',
                    createdAt: '2024-01-15',
                    updatedAt: '2024-01-19',
                    quantity: 115
                }, {
                name: 'Chia Seeds',
                expirationDate: '2025-04-10',
                createdAt: '2024-01-16',
                updatedAt: '2024-01-20',
                quantity: 100
            },
                {
                    name: 'Flax Seeds',
                    expirationDate: '2025-11-10',
                    createdAt: '2024-01-17',
                    updatedAt: '2024-01-21',
                    quantity: 130
                },
                {
                    name: 'Coconut Flour',
                    expirationDate: '2026-05-20',
                    createdAt: '2024-01-18',
                    updatedAt: '2024-01-22',
                    quantity: 50
                },
                {
                    name: 'Tapioca Flour',
                    expirationDate: '2025-09-05',
                    createdAt: '2024-01-19',
                    updatedAt: '2024-01-23',
                    quantity: 80
                },
                {
                    name: 'Peanut Butter',
                    expirationDate: '2025-03-18',
                    createdAt: '2024-01-20',
                    updatedAt: '2024-01-24',
                    quantity: 60
                },
                {
                    name: 'Almond Butter',
                    expirationDate: '2025-06-10',
                    createdAt: '2024-01-21',
                    updatedAt: '2024-01-25',
                    quantity: 40
                },
                {
                    name: 'Oatmeal',
                    expirationDate: '2025-12-01',
                    createdAt: '2024-01-22',
                    updatedAt: '2024-01-26',
                    quantity: 170
                },
                {
                    name: 'Honey',
                    expirationDate: '2026-08-15',
                    createdAt: '2024-01-23',
                    updatedAt: '2024-01-27',
                    quantity: 200
                },
                {
                    name: 'Maple Syrup',
                    expirationDate: '2025-10-20',
                    createdAt: '2024-01-24',
                    updatedAt: '2024-01-28',
                    quantity: 90
                },
                {
                    name: 'Cocoa Powder',
                    expirationDate: '2025-12-12',
                    createdAt: '2024-01-25',
                    updatedAt: '2024-01-29',
                    quantity: 110
                }
            ], {});
    },

    async down(queryInterface, Sequelize) {
        /**
         * Add commands to revert seed here.
         *
         * Example:
         * await queryInterface.bulkDelete('People', null, {});
         */
        await queryInterface.bulkDelete('Inventories', null, {});
    }
};
