'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('ShoppingSessions', [
            {
                name: 'Weekly Grocery Run',
                createdAt: new Date('2024-01-01T08:00:00Z'),
                updatedAt: new Date('2024-01-01T08:00:00Z'),
            },
            {
                name: 'Monthly Stock-Up',
                createdAt: new Date('2024-01-15T10:30:00Z'),
                updatedAt: new Date('2024-01-15T10:30:00Z'),
            },
            {
                name: 'Special Diet Plan',
                createdAt: new Date('2024-02-01T14:45:00Z'),
                updatedAt: new Date('2024-02-01T14:45:00Z'),
            },
            {
                name: 'Holiday Preparations',
                createdAt: new Date('2024-02-20T12:15:00Z'),
                updatedAt: new Date('2024-02-20T12:15:00Z'),
            },
            {
                name: 'Emergency Supplies',
                createdAt: new Date('2024-03-01T09:00:00Z'),
                updatedAt: new Date('2024-03-01T09:00:00Z'),
            }, {
                name: 'Weekly Veggie Run',
                createdAt: new Date('2024-01-12T08:15:00Z'),
                updatedAt: new Date('2024-01-12T08:15:00Z'),
            },
            {
                name: 'Home Cooking Essentials',
                createdAt: new Date('2024-01-25T11:45:00Z'),
                updatedAt: new Date('2024-01-25T11:45:00Z'),
            },
            {
                name: 'Health Supplement Shopping',
                createdAt: new Date('2024-02-10T16:00:00Z'),
                updatedAt: new Date('2024-02-10T16:00:00Z'),
            },
            {
                name: 'Baking Supplies Replenishment',
                createdAt: new Date('2024-02-18T14:00:00Z'),
                updatedAt: new Date('2024-02-18T14:00:00Z'),
            },
            {
                name: 'Weekly Protein Shop',
                createdAt: new Date('2024-03-05T09:45:00Z'),
                updatedAt: new Date('2024-03-05T09:45:00Z'),
            },
        ], {});
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('ShoppingSessions', null, {});
    }
};
