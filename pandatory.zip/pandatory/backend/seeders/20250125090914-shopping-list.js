'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        await queryInterface.bulkInsert('ShoppingLists', [
            {
                item_id: 1,
                quantity_to_buy: 5,
                purchased: false,
                session_id: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 3,
                quantity_to_buy: 2,
                purchased: false,
                session_id: 2,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 5,
                quantity_to_buy: 3,
                purchased: false,
                session_id: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 7,
                quantity_to_buy: 4,
                purchased: false,
                session_id: 3,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 9,
                quantity_to_buy: 1,
                purchased: false,
                session_id: 4,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 11,
                quantity_to_buy: 2,
                purchased: false,
                session_id: 5,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 13,
                quantity_to_buy: 6,
                purchased: false,
                session_id: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 15,
                quantity_to_buy: 3,
                purchased: false,
                session_id: 2,
                createdAt: new Date(),
                updatedAt: new Date(),
            }, {
                item_id: 2,
                quantity_to_buy: 5,
                purchased: false,
                session_id: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 4,
                quantity_to_buy: 3,
                purchased: false,
                session_id: 2,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 6,
                quantity_to_buy: 4,
                purchased: false,
                session_id: 3,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 8,
                quantity_to_buy: 2,
                purchased: false,
                session_id: 4,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 10,
                quantity_to_buy: 3,
                purchased: false,
                session_id: 5,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 12,
                quantity_to_buy: 5,
                purchased: false,
                session_id: 1,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 14,
                quantity_to_buy: 6,
                purchased: false,
                session_id: 2,
                createdAt: new Date(),
                updatedAt: new Date(),
            },
            {
                item_id: 16,
                quantity_to_buy: 2,
                purchased: false,
                session_id: 3,
                createdAt: new Date(),
                updatedAt: new Date(),
            }
        ], {});
    },

    async down(queryInterface, Sequelize) {
        await queryInterface.bulkDelete('ShoppingLists', null, {});
    }
};
