require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const adminRouter = require('./routers/admin');
const routers = require('./routers');
const app = express();

const CORS_ORIGIN = process.env.CORS_ORIGIN;

app.use(cors({
    origin: CORS_ORIGIN,
    methods: 'GET, POST, PUT, DELETE',
    allowedHeaders: 'Content-Type, Authorization',
}));

app.use(bodyParser.json());

app.get("/", adminRouter);

app.use("/api/v1", routers);

module.exports = app;
