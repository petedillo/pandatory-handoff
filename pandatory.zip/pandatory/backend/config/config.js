module.exports = {
    development: {
        username: process.env.DB_USER || "postgres",
        password: process.env.DB_PASSWORD || "pp5",
        database: process.env.DB_NAME || "pandatory_db",
        host: process.env.DB_HOST || "localhost",
        dialect: "postgres",
        define: {
            getterMethods: {
                createdAt() {
                    return this.getDataValue("createdAt")
                        ? this.getDataValue("createdAt").toISOString().split("T")[0]
                        : null;
                },
                expirationDate() {
                    return this.getDataValue("expirationDate")
                        ? this.getDataValue("expirationDate").toISOString().split("T")[0]
                        : null;
                },
            },
        },
    },
    production: {
        username: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOST,
        dialect: "postgres",
        define: {
            getterMethods: {
                createdAt() {
                    return this.getDataValue("createdAt")
                        ? this.getDataValue("createdAt").toISOString().split("T")[0]
                        : null;
                },
                expirationDate() {
                    return this.getDataValue("expirationDate")
                        ? this.getDataValue("expirationDate").toISOString().split("T")[0]
                        : null;
                },
            },
        },
    },
};
