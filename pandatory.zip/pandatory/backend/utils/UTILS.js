const {ShoppingSession, Inventory} = require('../models');

const validateSession = async (sessionId) => {
    return await ShoppingSession.findByPk(sessionId);
};

const validateItems = async (itemIds) => {
    const items = await Inventory.findAll({where: {id: itemIds}});
    return items.length === itemIds.length;
};

module.exports = {
    validateSession,
    validateItems
};
