const {ShoppingSession, ShoppingList, Inventory} = require('../models');
const {validateSession, validateItems} = require('../utils/UTILS');

const getAll = async (req, res) => {
    const {archived} = req.query;
    try {
        const filter = {};
        if (archived === 'true') filter.archive = true;
        else if (archived === 'false') filter.archive = false;

        const sessions = await ShoppingSession.findAll({
            where: filter,
            include: {
                model: ShoppingList,
                as: 'shoppingLists',
                include: {
                    model: Inventory,
                    as: 'inventoryItem'
                }
            },
            order: [
                ['updatedAt', 'DESC'],
            ]
        });
        res.json(sessions);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error fetching shopping sessions'});
    }
};


const create = async (req, res) => {
    const {name, archive} = req.body;
    try {
        const newSession = await ShoppingSession.create({name, archive});
        console.log(newSession)
        res.status(201).json(newSession);
    } catch (error) {
        console.error(error);
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({message: 'Shopping session with this name already exists'});
        }
        res.status(400).json({message: 'Error creating shopping session'});
    }
};

const getById = async (req, res) => {
    const {id} = req.params;
    try {
        const session = await ShoppingSession.findByPk(id, {
            include: {
                model: ShoppingList,
                as: 'shoppingLists',
                include: {
                    model: Inventory,
                    as: 'inventoryItem'
                }
            }
        });
        if (!session) {
            return res.status(404).json({message: 'Shopping session not found'});
        }
        res.json(session);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error fetching shopping session'});
    }
};

const remove = async (req, res) => {
    const {id} = req.params;
    try {
        const deletedCount = await ShoppingSession.destroy({where: {id}});
        if (deletedCount === 0) {
            return res.status(404).json({message: 'Shopping session not found'});
        }
        res.json({message: 'Shopping session deleted'});
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error deleting shopping session'});
    }
};

const archive = async (req, res) => {
    const {id} = req.params;
    try {
        const session = await validateSession(id);
        if (!session) {
            return res.status(404).json({message: 'Session not found'});
        }
        session.archive = true;
        await session.save();
        res.status(200).json(session);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error archiving the session'});
    }
};

const addItems = async (req, res) => {
    try {
        const {sessionId} = req.params;
        const {itemIds} = req.body;
        if (!Array.isArray(itemIds) || itemIds.length === 0) {
            return res.status(400).json({message: 'Item IDs must be a non-empty array.'});
        }
        const session = await validateSession(sessionId);
        if (!session) {
            return res.status(404).json({message: 'Shopping session not found.'});
        }
        if (!(await validateItems(itemIds))) {
            return res.status(400).json({message: 'One or more items not found.'});
        }
        const shoppingListEntries = itemIds.map(itemId => ({
            session_id: sessionId,
            item_id: itemId,
            purchased: false,
        }));
        await ShoppingList.bulkCreate(shoppingListEntries);
        res.status(201).json({message: 'Items added to shopping session successfully.'});
    } catch (error) {
        console.error('Error adding items to shopping session:', error);
        res.status(500).json({message: 'Internal server error.'});
    }
};

const markPurchased = async (req, res) => {
    try {
        const {sessionId} = req.params;
        const {itemIds} = req.body;

        if (!Array.isArray(itemIds) || itemIds.length === 0) {
            return res.status(400).json({message: 'Item IDs must be a non-empty array.'});
        }

        const session = await validateSession(sessionId);
        if (!session) {
            return res.status(404).json({message: 'Shopping session not found.'});
        }

        await ShoppingList.update(
            {purchased: true},
            {where: {session_id: sessionId, item_id: itemIds}}
        );

        const countResult = await ShoppingList.findAndCountAll({
            where: {session_id: sessionId, purchased: false}
        });
        const allItemsPurchased = countResult.count === 0;

        if (allItemsPurchased) {
            session.archive = true;
            await session.save();
        }

        res.status(200).json({message: 'Items marked as purchased successfully.'});
    } catch (error) {
        console.error('Error marking items as purchased:', error);
        res.status(500).json({message: 'Internal server error.'});
    }
};

const updateQuantityToBuy = async (req, res) => {
    try {
        const {sessionId, itemId} = req.params;
        const {quantity_to_buy} = req.body;

        // Validate the session and item
        const session = await validateSession(sessionId);
        if (!session) {
            return res.status(404).json({message: 'Shopping session not found.'});
        }

        const item = await validateItems([itemId]);
        if (!item || item.length === 0) {
            return res.status(404).json({message: 'Item not found.'});
        }

        // Find the shopping list entry
        const shoppingListEntry = await ShoppingList.findOne({
            where: {
                session_id: sessionId,
                item_id: itemId,
            },
        });

        if (!shoppingListEntry) {
            return res.status(404).json({message: 'Item not found in the shopping list.'});
        }

        // Update the quantity_to_buy field
        shoppingListEntry.quantity_to_buy = quantity_to_buy;
        await shoppingListEntry.save();

        res.status(200).json({message: 'Quantity to buy updated successfully.', shoppingListEntry});
    } catch (error) {
        console.error('Error updating quantity to buy:', error);
        res.status(500).json({message: 'Internal server error.'});
    }
};

module.exports = {
    getAll,
    create,
    getById,
    remove,
    archive,
    addItems,
    markPurchased,
    updateQuantityToBuy,
};
