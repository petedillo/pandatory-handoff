const {Inventory, ShoppingList} = require('../models');
const {Op} = require("sequelize");

// Function to get all inventories
const getAll = async (req, res) => {
    try {
        const inventories = await Inventory.findAll({
            include: [
                {
                    model: ShoppingList,
                    as: 'shoppingLists',
                },
            ],
        });
        res.json(inventories);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error fetching inventories'});
    }
};

// Function to create a new inventory item
const create = async (req, res) => {
    const {name, expirationDate, quantity} = req.body;

    try {
        const newInventory = await Inventory.create({name, expirationDate, quantity});
        res.status(201).json(newInventory);
    } catch (error) {
        console.error(error);

        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({message: 'Inventory with this name already exists'});
        }

        res.status(400).json({message: 'Error creating inventory'});
    }
};

// Function to get an inventory by ID (with related shopping lists)
const getById = async (req, res) => {
    const {id} = req.params;

    try {
        const inventory = await Inventory.findByPk(id, {
            include: [
                {
                    model: ShoppingList,
                    as: 'shoppingLists',
                },
            ],
        });

        if (!inventory) {
            return res.status(404).json({message: 'Inventory not found'});
        }

        res.json(inventory);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error fetching inventory'});
    }
};

// Function to delete an inventory item
const remove = async (req, res) => {
    const {id} = req.params;

    try {
        const deletedCount = await Inventory.destroy({where: {id}});

        if (deletedCount === 0) {
            return res.status(404).json({message: 'Inventory not found'});
        }

        res.json({message: 'Inventory deleted'});
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error deleting inventory'});
    }
};

// Function to search for inventory items
const search = async (req, res) => {
    try {
        const whereClause = {};
        if (req.query.name) {
            whereClause.name = {[Op.iLike]: `%${req.query.name}%`};
        }

        if (req.query.expirationDate) {
            whereClause.expirationDate = {[Op.like]: `%${req.query.expirationDate}%`};
        }

        const results = await Inventory.findAll({
            where: whereClause,
            include: [
                {
                    model: ShoppingList,
                    as: 'shoppingLists',
                },
            ],
        });

        res.json({results});
    } catch (error) {
        console.error(error);
        res.status(500).json({error: 'Failed to search'});
    }
};

// Function to update an inventory item
const update = async (req, res) => {
    const {id} = req.params;
    const {name, expirationDate, quantity} = req.body;
    try {
        const formattedExpirationDate = expirationDate
            ? new Date(expirationDate).toISOString()
            : null;

        const inventory = await Inventory.findByPk(id);

        if (!inventory) {
            return res.status(404).json({message: 'Inventory not found'});
        }

        const updatedInventory = await inventory.update({
            name,
            expirationDate: formattedExpirationDate,
            quantity,
        });

        res.json(updatedInventory);
    } catch (error) {
        console.error(error);

        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({message: 'Inventory with this name already exists'});
        }

        res.status(500).json({message: 'Error updating inventory'});
    }
};


module.exports = {
    getAll,
    create,
    getById,
    remove,
    search,
    update,
};
