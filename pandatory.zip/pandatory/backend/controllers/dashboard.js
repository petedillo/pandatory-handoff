const {Inventory, ShoppingSession} = require('../models');
const {Op} = require('sequelize');

// Function to get all inventories
const getDashboardStats = async (req, res) => {
    try {
        const totalItems = await Inventory.count();

        // Expiring soon (next 7 days)
        const expiringSoon = await Inventory.count({
            where: {
                expirationDate: {
                    [Op.between]: [new Date(), new Date(new Date().setDate(new Date().getDate() + 7))],
                },
            },
        });

        // Needs attention (expired items)
        const needsAttention = await Inventory.count({
            where: {
                expirationDate: {
                    [Op.lt]: new Date(), // Less than today
                },
            },
        });

        const totalSessions = await ShoppingSession.count();

        res.json({totalItems, expiringSoon, needsAttention, totalSessions});
    } catch (error) {
        console.error("Error fetching dashboard data:", error);
        res.status(500).json({message: "Internal server error"});
    }
};

module.exports = {
    getDashboardStats
}