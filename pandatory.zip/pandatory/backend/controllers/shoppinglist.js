const {ShoppingList, Inventory, ShoppingSession} = require('../models');
const {Op} = require('sequelize');

// Function to get all shopping list items
const getAll = async (req, res) => {
    try {
        const shoppingLists = await ShoppingList.findAll({
            include: [
                {model: Inventory, as: 'inventoryItem'},
                {model: ShoppingSession, as: 'shoppingSession'},
            ],
        });
        res.json(shoppingLists);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error fetching shopping list items'});
    }
};

// Function to create a new shopping list item
const create = async (req, res) => {
    const {item_id, quantity, purchased, session_id} = req.body;

    try {
        const newShoppingListItem = await ShoppingList.create({item_id, quantity, purchased, session_id});
        res.status(201).json(newShoppingListItem);
    } catch (error) {
        console.error(error);
        res.status(400).json({message: 'Error creating shopping list item'});
    }
};

// Function to get a shopping list item by ID
const getById = async (req, res) => {
    const {id} = req.params;

    try {
        const shoppingListItem = await ShoppingList.findByPk(id, {
            include: [
                {model: Inventory, as: 'inventoryItem'},
                {model: ShoppingSession, as: 'shoppingSession'},
            ],
        });

        if (!shoppingListItem) {
            return res.status(404).json({message: 'Shopping list item not found'});
        }

        res.json(shoppingListItem);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error fetching shopping list item'});
    }
};

// Function to delete a shopping list item
const remove = async (req, res) => {
    const {id} = req.params;

    try {
        const deletedCount = await ShoppingList.destroy({where: {id}});

        if (deletedCount === 0) {
            return res.status(404).json({message: 'Shopping list item not found'});
        }

        res.json({message: 'Shopping list item deleted'});
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error deleting shopping list item'});
    }
};

// Function to update a shopping list item
const update = async (req, res) => {
    const {id} = req.params;
    const {item_id, quantity, purchased, session_id} = req.body;

    try {
        const shoppingListItem = await ShoppingList.findByPk(id);

        if (!shoppingListItem) {
            return res.status(404).json({message: 'Shopping list item not found'});
        }

        const updatedShoppingListItem = await shoppingListItem.update({item_id, quantity, purchased, session_id});
        res.json(updatedShoppingListItem);
    } catch (error) {
        console.error(error);
        res.status(500).json({message: 'Error updating shopping list item'});
    }
};

module.exports = {
    getAll,
    create,
    getById,
    remove,
    update,
};
